Compile: javac Main.java Patient.java Doctor.java
Run: java Main