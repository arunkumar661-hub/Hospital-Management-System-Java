import java.util.*;
public class Main{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        Patient[] patients=new Patient[100];
        Doctor[] doctors=new Doctor[20];
        int pCount=0,dCount=0,ch;
        do{
            System.out.println("\nHospital Management System");
            System.out.println("1.Add Patient");
            System.out.println("2.View Patients");
            System.out.println("3.Search Patient");
            System.out.println("4.Add Doctor");
            System.out.println("5.View Doctors");
            System.out.println("6.Generate Bill");
            System.out.println("7.Exit");
            System.out.print("Choice: ");
            try{ ch=sc.nextInt(); }catch(Exception e){ System.out.println("Invalid"); sc.nextLine(); ch=0;}
            switch(ch){
                case 1:
                    System.out.print("ID: "); int id=sc.nextInt(); sc.nextLine();
                    System.out.print("Name: "); String n=sc.nextLine();
                    System.out.print("Age: "); int a=sc.nextInt(); sc.nextLine();
                    System.out.print("Disease: "); String d=sc.nextLine();
                    patients[pCount++]=new Patient(id,n,a,d);
                    System.out.println("Added");
                    break;
                case 2:
                    if(pCount==0) System.out.println("No patients");
                    for(int i=0;i<pCount;i++) patients[i].display();
                    break;
                case 3:
                    System.out.print("Enter ID: "); int sid=sc.nextInt(); boolean f=false;
                    for(int i=0;i<pCount;i++) if(patients[i].id==sid){patients[i].display();f=true;}
                    if(!f) System.out.println("Not found");
                    break;
                case 4:
                    System.out.print("Doctor ID: "); int did=sc.nextInt(); sc.nextLine();
                    System.out.print("Name: "); String dn=sc.nextLine();
                    System.out.print("Specialization: "); String sp=sc.nextLine();
                    doctors[dCount++]=new Doctor(did,dn,sp);
                    break;
                case 5:
                    for(int i=0;i<dCount;i++) doctors[i].display();
                    break;
                case 6:
                    System.out.print("Consultation Fee: "); double c=sc.nextDouble();
                    System.out.print("Medicine Cost: "); double m=sc.nextDouble();
                    double total=c+m;
                    StringBuilder sb=new StringBuilder();
                    sb.append("----- BILL -----\nConsultation: ").append(c)
                      .append("\nMedicine: ").append(m)
                      .append("\nTotal: ").append(total);
                    System.out.println(sb);
                    break;
                case 7: System.out.println("Thank you!"); break;
                default:System.out.println("Invalid choice");
            }
        }while(ch!=7);
        sc.close();
    }
}
